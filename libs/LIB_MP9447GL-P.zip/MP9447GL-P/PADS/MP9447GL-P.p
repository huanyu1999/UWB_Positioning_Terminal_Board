*PADS-LIBRARY-PART-TYPES-V9*

MP9447GL-P MP9447GLP I ANA 9 1 0 0 0
TIMESTAMP 2026.08.11.06.54.45
"Manufacturer_Name" Monolithic Power Systems (MPS)
"Manufacturer_Part_Number" MP9447GL-P
"Mouser Part Number" 946-MP9447GL-P
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Monolithic-Power-Systems-MPS/MP9447GL-P?qs=IW9Tsl75qsUmFNM3HzTlSA%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Switching Voltage Regulators 36V,5A,650kHz Sync Buck with Adj. Freq
"Datasheet Link" http://www.monolithicpower.com/pub/media/document/MP9447_r1.2.pdf
"Geometry.Height" 1mm
GATE 1 25 0
MP9447GL-P
1 0 U AGND
2 0 U FREQ
3 0 U FB
4 0 U SS
5 0 U EN
6 0 U NC
7 0 U BST
8 0 U IN_1
9 0 U SW_1
10 0 U SW_2
11 0 U PGND_1
12 0 U PGND_2
13 0 U PGND_3
14 0 U PGND_4
15 0 U PGND_5
16 0 U PGND_6
17 0 U SW_3
18 0 U SW_4
19 0 U IN_2
20 0 U VCC
21 0 U IN_3
22 0 U IN_4
23 0 U IN_5
24 0 U SW_5
25 0 U SW_6

*END*
*REMARK* SamacSys ECAD Model
1291638/1400036/2.50/25/3/Integrated Circuit
