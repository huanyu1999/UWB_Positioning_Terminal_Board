*PADS-LIBRARY-PART-TYPES-V9*

PESD5V0L2BT-QR SOT95P230X110-3N I ANA 9 1 0 0 0
TIMESTAMP 2026.08.11.10.12.57
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PESD5V0L2BT-QR
"Mouser Part Number" 771-PESD5V0L2BT-QR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PESD5V0L2BT-QR?qs=vvQtp7zwQdORLHkH1w26Gw%3D%3D
"Arrow Part Number" PESD5V0L2BT-QR
"Arrow Price/Stock" https://www.arrow.com/en/products/pesd5v0l2bt-qr/nexperia.html?utm_currency=USD&region=nac
"Description" PESD5V0L2BT-Q - Low capacitance double bidirectional ESD protection diode in SOT23@en-us
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/PESD5V0L2BT-Q.pdf
"Geometry.Height" 1.1mm
GATE 1 3 0
PESD5V0L2BT-QR
1 0 U K1
2 0 U K2
3 0 U COM_K

*END*
*REMARK* SamacSys ECAD Model
17252213/1400036/2.50/3/2/Diode ESD (Bi-directional)
