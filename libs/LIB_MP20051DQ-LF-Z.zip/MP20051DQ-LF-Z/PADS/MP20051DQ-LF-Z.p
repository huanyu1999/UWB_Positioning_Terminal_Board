*PADS-LIBRARY-PART-TYPES-V9*

MP20051DQ-LF-Z SON65P300X300X100-9N-D I ANA 9 1 0 0 0
TIMESTAMP 2026.08.11.06.58.16
"Manufacturer_Name" Monolithic Power Systems (MPS)
"Manufacturer_Part_Number" MP20051DQ-LF-Z
"Mouser Part Number" 946-MP20051DQLFZ
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Monolithic-Power-Systems-MPS/MP20051DQ-LF-Z?qs=UmMSjoC1xtGYGMIV3kjR7Q%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" LDO Voltage Regulators Low Noise High PSRR 1A Linear Regulator
"Datasheet Link" https://www.monolithicpower.com/en/documentview/productdocument/index/version/2/document_type/Datasheet/lang/en/sku/MP20051/
"Geometry.Height" 1mm
GATE 1 9 0
MP20051DQ-LF-Z
1 0 U OUT_1
2 0 U OUT_2
3 0 U FB
4 0 U GND
9 0 U EP
8 0 U IN_2
7 0 U IN_1
6 0 U NC
5 0 U EN

*END*
*REMARK* SamacSys ECAD Model
2376529/1400036/2.50/9/3/Integrated Circuit
