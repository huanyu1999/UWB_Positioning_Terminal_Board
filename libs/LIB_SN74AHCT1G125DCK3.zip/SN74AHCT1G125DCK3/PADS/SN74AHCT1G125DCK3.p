*PADS-LIBRARY-PART-TYPES-V9*

SN74AHCT1G125DCK3 SOT65P210X110-5N I ANA 9 1 0 0 0
TIMESTAMP 2026.08.13.08.13.50
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74AHCT1G125DCK3
"Mouser Part Number" 595-74AHCT1G125DCK3
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74AHCT1G125DCK3?qs=byeeYqUIh0PfZxd3i5oWFg%3D%3D
"Arrow Part Number" SN74AHCT1G125DCK3
"Arrow Price/Stock" https://www.arrow.com/en/products/sn74ahct1g125dck3/texas-instruments?utm_currency=USD&region=nac
"Description" Buffers & Line Drivers Single Bus Buffer Gate With 3-State Output 5-SC70 -40 to 85
"Datasheet Link" https://www.ti.com/lit/ds/symlink/sn74ahct1g125.pdf?HQS=TI-null-null-digikeymode-df-pf-null-wwe&ts=1605443569597
"Geometry.Height" 1.1mm
GATE 1 5 0
SN74AHCT1G125DCK3
1 0 U \OE
2 0 U A
3 0 U GND
4 0 U Y
5 0 U VCC

*END*
*REMARK* SamacSys ECAD Model
1488254/1400036/2.50/5/3/Integrated Circuit
