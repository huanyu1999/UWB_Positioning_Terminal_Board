*PADS-LIBRARY-PART-TYPES-V9*

DLW21SN900SQ2L DLW21SN121HQ2L I IND 9 1 0 0 0
TIMESTAMP 2026.08.17.04.57.16
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" DLW21SN900SQ2L
"Mouser Part Number" 81-DLW21SN900SQ2L
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Murata-Electronics/DLW21SN900SQ2L?qs=yQ3nQrcaeVsNzdZbwxOhwQ%3D%3D
"Arrow Part Number" DLW21SN900SQ2L
"Arrow Price/Stock" https://www.arrow.com/en/products/dlw21sn900sq2l_2/murata-manufacturing.html?utm_currency=USD&region=europe
"Description" Murata, DLW21S, 0805 (2012M) Wire-wound SMD Inductor +/-25% Wire-Wound 330mA Idc
"Datasheet Link" https://datasheet.datasheetarchive.com/originals/distributors/Datasheets_SAMA/ece8820704b5ec0ab68e5b2fda1b5649.pdf
"Geometry.Height" 1.4mm
GATE 1 4 0
DLW21SN900SQ2L
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4

*END*
*REMARK* SamacSys ECAD Model
860753/1400036/2.50/4/2/Inductor
