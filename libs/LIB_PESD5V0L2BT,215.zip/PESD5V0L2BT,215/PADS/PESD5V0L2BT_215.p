*PADS-LIBRARY-PART-TYPES-V9*

PESD5V0L2BT_215 SOT95P230X110-3N I ANA 9 1 0 0 0
TIMESTAMP 2026.08.12.02.34.17
"Manufacturer_Name" Nexperia
"Manufacturer_Part_Number" PESD5V0L2BT,215
"Mouser Part Number" 771-PESD5V0L2BT-T/R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nexperia/PESD5V0L2BT215?qs=LOCUfHb8d9sw%252B%2FcZzpNtzw%3D%3D
"Arrow Part Number" PESD5V0L2BT,215
"Arrow Price/Stock" https://www.arrow.com/en/products/pesd5v0l2bt215/nexperia.html?utm_currency=USD&region=nac
"Description" Low capacitance double bidirectional ESD protection diodes in SOT23 13A 30kV
"Datasheet Link" https://assets.nexperia.com/documents/data-sheet/PESDXL2BT_SER.pdf
"Geometry.Height" 1.1mm
GATE 1 3 0
PESD5V0L2BT_215
1 0 U CATHODE_1
2 0 U CATHODE_2
3 0 U DOUBLE_CATHODE

*END*
*REMARK* SamacSys ECAD Model
700856/1400036/2.50/3/2/Diode ESD (Bi-directional)
