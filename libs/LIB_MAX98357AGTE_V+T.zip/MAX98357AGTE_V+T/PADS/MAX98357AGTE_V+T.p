*PADS-LIBRARY-PART-TYPES-V9*

MAX98357AGTE_V+T QFN50P300X300X80-17N I ANA 9 1 0 0 0
TIMESTAMP 2026.08.14.09.49.32
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" MAX98357AGTE/V+T
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Tiny, Low-Cost, PCM Class D Amplifier with Class AB Performance
"Datasheet Link" https://pdfserv.maximintegrated.com/en/ds/MAX98357A-MAX98357B.pdf
"Geometry.Height" 0.8mm
GATE 1 17 0
MAX98357AGTE_V+T
1 0 U DIN
2 0 U GAIN_SLOT
3 0 U GND_1
4 0 U \SD_MODE
5 0 U N.C._1
6 0 U N.C._2
7 0 U VDD_1
8 0 U VDD_2
12 0 U N.C._3
11 0 U GND_2
10 0 U OUTN
9 0 U OUTP
17 0 U EP
16 0 U BCLK
15 0 U GND_3
14 0 U LRCLK
13 0 U N.C._4

*END*
*REMARK* SamacSys ECAD Model
13005822/1400036/2.50/17/2/Integrated Circuit
